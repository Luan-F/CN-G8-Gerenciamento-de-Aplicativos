cd html
python -m http.server 3000
